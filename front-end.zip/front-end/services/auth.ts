import { apiClient } from "../lib/api";
import { LoginData, RegisterData, User } from "@/types/auth";


export const authApi = {
  async login(data: LoginData): Promise<{ user: User; token: string }> {
    const response = await apiClient.post<{ user: User; token: string }>("/api/auth/login", data);
    return response;
  },

  async register(data: RegisterData): Promise<{ user: User; token: string }> {
    const response = await apiClient.post<{ user: User; token: string }>("/api/auth/register", data);
    return response;
  },

  async logout(): Promise<void> {
    await apiClient.post<void>("/api/auth/logout");
  },

  async getUser(): Promise<User> {
    const response = await apiClient.get<User>("/api/auth/me");
    return response;
  }
};