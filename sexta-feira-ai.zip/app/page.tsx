import { LandingPage } from "@/components/landing-page"

export default function HomePage() {
  // Aqui você pode verificar se o usuário está logado
  // const isAuthenticated = await checkAuth()
  // if (isAuthenticated) {
  //   redirect("/dashboard")
  // }

  return <LandingPage />
}
