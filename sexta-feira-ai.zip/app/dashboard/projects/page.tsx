import { Projects } from "@/components/projects/projects"

export default function ProjectsPage() {
  return <Projects />
}
